extends CharacterBody2D

@export var max_health: int = 50
var current_health: int = max_health

@export var knockback_decay: float = 1200.0
var knockback_velocity: Vector2 = Vector2.ZERO

@export var move_speed: float = 160.0
@export var gravity: float = 980.0
@onready var animatedsprite = $AnimatedSprite2D

@onready var detection_area: Area2D = $detection
var target_player: Node2D = null

func _physics_process(delta: float) -> void:
	# Apply gravity
	if not is_on_floor():
		velocity.y += gravity * delta
	
	var direction = 0
	
	# Chase player along the X-axis if detected
	if target_player:
		direction = sign(target_player.global_position.x - global_position.x)
		velocity.x = direction * move_speed
	else:
		velocity.x = 0.0
		
	if direction != 0:
		animatedsprite.play("running")
		animatedsprite.flip_h = direction < 0	
	else:
		animatedsprite.play("idle")
		
	# Apply knockback force if present and clear it instantly so it doesn't stack
	if knockback_velocity != Vector2.ZERO:
		velocity.y = knockback_velocity.y
		knockback_velocity = Vector2.ZERO

	move_and_slide()

# --- Health & Damage Handler ---
func take_damage(amount: int) -> void:
	current_health -= amount
	print("Enemy hit! Remaining health: ", current_health)
	
	# Visual red flash effect on hit
	var tween = create_tween()
	tween.tween_property(animatedsprite, "modulate", Color.RED, 0.1)
	tween.tween_property(animatedsprite, "modulate", Color.WHITE, 0.1)

	if current_health <= 0:
		die()

func die() -> void:
	queue_free()

# --- Vertical Hit Hop ---
func take_knockback(hit_source_position: Vector2, force: float = 250.0) -> void:
	# Gives a controlled pop upward (similar to a small jump)
	knockback_velocity = Vector2(0.0, -force)

func _on_detection_body_entered(body: Node2D) -> void:
	if body.is_in_group("playergroup"):
		target_player = body

func _on_detection_body_exited(body: Node2D) -> void:
	if body == target_player:
		target_player = null
