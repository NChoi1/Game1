extends CharacterBody2D

@export var knockback_decay: float = 1200.0
var knockback_velocity: Vector2 = Vector2.ZERO

@export var push_force: float = 100
@onready var animatedsprite = $AnimatedSprite2D

const SPEED = 350.0
const JUMP_VELOCITY = -400.0

func _physics_process(delta: float) -> void:
	_handle_rigidbody_push()
	
	# Apply gravity
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Apply knockback once and immediately clear it
	if knockback_velocity != Vector2.ZERO:
		velocity.y = knockback_velocity.y
		knockback_velocity = Vector2.ZERO

	# Handle jump
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Handle movement
	var direction := Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	# Spit animation logic
	if Input.is_action_just_pressed("fire") and not (animatedsprite.animation == "spit" and animatedsprite.is_playing()):
		animatedsprite.play("spit")

	if animatedsprite.animation != "spit" or not animatedsprite.is_playing():
		if direction != 0:
			animatedsprite.play("run")
			animatedsprite.flip_h = direction < 0
		else:
			animatedsprite.play("idle")
	else:
		if direction != 0:
			animatedsprite.flip_h = direction < 0

	move_and_slide()

func _on_area_2d_area_entered(area: Area2D) -> void:
	if area.is_in_group("death"):
		get_tree().call_deferred("reload_current_scene")

	if area.is_in_group("exit_to_world2"):
		get_tree().call_deferred("change_scene_to_file", "res://scenes/world2.tscn") 

	if area.is_in_group("enemy_hitbox"):
		take_damage_and_knockback(area)

func take_damage_and_knockback(hit_source: Area2D) -> void:
	# Bounces the player straight up like taking damage in Mario/Hollow Knight
	knockback_velocity = Vector2(0.0, -250.0)
	
	trigger_hit_stop()

func trigger_hit_stop() -> void:
	Engine.time_scale = 0.2
	await get_tree().create_timer(0.05, true, false, true).timeout
	Engine.time_scale = 1.0

func _handle_rigidbody_push() -> void:
	for i in get_slide_collision_count():
		var collision := get_slide_collision(i)
		var collider := collision.get_collider()
		if collider is RigidBody2D:
			var push_direction := -collision.get_normal()
			collider.apply_central_impulse(push_direction * push_force)

func _on_hurtbox_area_entered(area: Area2D) -> void:
	_on_area_2d_area_entered(area)
