extends CharacterBody2D

@export var max_health: int = 50
var current_health: int = max_health

@export var attack_damage: int = 20
@export var move_speed: float = 160.0

@onready var animatedsprite: AnimatedSprite2D = $AnimatedSprite2D

var target_player: Node2D = null
var is_attacking: bool = false
var player_in_attack_range: bool = false

func _ready() -> void:
	if not is_in_group("enemygroup"):
		add_to_group("enemygroup")
		
	if animatedsprite and not animatedsprite.animation_finished.is_connected(_on_animation_finished):
		animatedsprite.animation_finished.connect(_on_animation_finished)

func _physics_process(delta: float) -> void:
	# Apply gravity
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Freeze movement while attacking
	if is_attacking:
		velocity.x = 0.0
		move_and_slide()
		return

	# Follow or Attack player
	if target_player:
		var direction = sign(target_player.global_position.x - global_position.x)
		
		if direction != 0:
			animatedsprite.flip_h = direction < 0

		# If inside the attack area, stop and attack!
		if player_in_attack_range:
			velocity.x = 0.0
			_perform_attack()
		else:
			velocity.x = direction * move_speed
			animatedsprite.play("running")
	else:
		velocity.x = 0.0
		animatedsprite.play("idle")

	move_and_slide()

func _perform_attack() -> void:
	# Prevent spamming attacks while already mid-animation
	if is_attacking:
		return
		
	is_attacking = true
	velocity.x = 0.0
	animatedsprite.play("attack")

func _on_animation_finished() -> void:
	if animatedsprite.animation == "attack":
		is_attacking = false
		
		# Deal damage if player is still in the attack area when the animation finishes
		if target_player and player_in_attack_range:
			if target_player.has_method("take_damage"):
				target_player.take_damage(attack_damage)

# Health & Damage
func take_damage(amount: int) -> void:
	current_health = max(current_health - amount, 0)
	if current_health <= 0:
		queue_free()

# --- Detection Signals ---
func _on_detection_body_entered(body: Node2D) -> void:
	if body.is_in_group("playergroup"):
		target_player = body

func _on_detection_body_exited(body: Node2D) -> void:
	if body == target_player:
		target_player = null
		player_in_attack_range = false

# --- Attack Area Signals (Make sure these are connected in your Node tab!) ---
func _on_attack_area_body_entered(body: Node2D) -> void:
	if body.is_in_group("playergroup") or body == target_player:
		player_in_attack_range = true

func _on_attack_area_body_exited(body: Node2D) -> void:
	if body.is_in_group("playergroup") or body == target_player:
		player_in_attack_range = false
